/****************************************************************************
** Meta object code from reading C++ file 'optionscontroller.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ClockGame/optionscontroller.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'optionscontroller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_OptionsController_t {
    QByteArrayData data[18];
    char stringdata0[267];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_OptionsController_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_OptionsController_t qt_meta_stringdata_OptionsController = {
    {
QT_MOC_LITERAL(0, 0, 17), // "OptionsController"
QT_MOC_LITERAL(1, 18, 21), // "animationSpeedClicked"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 5), // "index"
QT_MOC_LITERAL(4, 47, 17), // "difficultyClicked"
QT_MOC_LITERAL(5, 65, 19), // "volumeToggleClicked"
QT_MOC_LITERAL(6, 85, 15), // "volumeUpClicked"
QT_MOC_LITERAL(7, 101, 17), // "volumeDownClicked"
QT_MOC_LITERAL(8, 119, 11), // "modeClicked"
QT_MOC_LITERAL(9, 131, 21), // "getCurrentGlobalSpeed"
QT_MOC_LITERAL(10, 153, 26), // "getCurrentGlobalDifficulty"
QT_MOC_LITERAL(11, 180, 21), // "getCurrentGlobalMuted"
QT_MOC_LITERAL(12, 202, 20), // "getCurrentGlobalMode"
QT_MOC_LITERAL(13, 223, 6), // "volume"
QT_MOC_LITERAL(14, 230, 5), // "muted"
QT_MOC_LITERAL(15, 236, 10), // "difficulty"
QT_MOC_LITERAL(16, 247, 14), // "animationSpeed"
QT_MOC_LITERAL(17, 262, 4) // "mode"

    },
    "OptionsController\0animationSpeedClicked\0"
    "\0index\0difficultyClicked\0volumeToggleClicked\0"
    "volumeUpClicked\0volumeDownClicked\0"
    "modeClicked\0getCurrentGlobalSpeed\0"
    "getCurrentGlobalDifficulty\0"
    "getCurrentGlobalMuted\0getCurrentGlobalMode\0"
    "volume\0muted\0difficulty\0animationSpeed\0"
    "mode"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_OptionsController[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       5,   82, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   64,    2, 0x0a /* Public */,
       4,    1,   67,    2, 0x0a /* Public */,
       5,    1,   70,    2, 0x0a /* Public */,
       6,    0,   73,    2, 0x0a /* Public */,
       7,    0,   74,    2, 0x0a /* Public */,
       8,    1,   75,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
       9,    0,   78,    2, 0x02 /* Public */,
      10,    0,   79,    2, 0x02 /* Public */,
      11,    0,   80,    2, 0x02 /* Public */,
      12,    0,   81,    2, 0x02 /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,

 // methods: parameters
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,

 // properties: name, type, flags
      13, QMetaType::Int, 0x00095103,
      14, QMetaType::Bool, 0x00095103,
      15, QMetaType::Int, 0x00095103,
      16, QMetaType::Int, 0x00095103,
      17, QMetaType::Int, 0x00095103,

       0        // eod
};

void OptionsController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        OptionsController *_t = static_cast<OptionsController *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->animationSpeedClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->difficultyClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->volumeToggleClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->volumeUpClicked(); break;
        case 4: _t->volumeDownClicked(); break;
        case 5: _t->modeClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: { int _r = _t->getCurrentGlobalSpeed();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 7: { int _r = _t->getCurrentGlobalDifficulty();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 8: { int _r = _t->getCurrentGlobalMuted();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 9: { int _r = _t->getCurrentGlobalMode();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        OptionsController *_t = static_cast<OptionsController *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->volume(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->muted(); break;
        case 2: *reinterpret_cast< int*>(_v) = _t->difficulty(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->animationSpeed(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->mode(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        OptionsController *_t = static_cast<OptionsController *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setVolume(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setMuted(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setDifficulty(*reinterpret_cast< int*>(_v)); break;
        case 3: _t->setAnimationSpeed(*reinterpret_cast< int*>(_v)); break;
        case 4: _t->setMode(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject OptionsController::staticMetaObject = {
    { &QQuickItem::staticMetaObject, qt_meta_stringdata_OptionsController.data,
      qt_meta_data_OptionsController,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *OptionsController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *OptionsController::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_OptionsController.stringdata0))
        return static_cast<void*>(const_cast< OptionsController*>(this));
    return QQuickItem::qt_metacast(_clname);
}

int OptionsController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
